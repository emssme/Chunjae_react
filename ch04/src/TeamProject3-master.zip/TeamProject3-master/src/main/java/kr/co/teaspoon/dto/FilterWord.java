package kr.co.teaspoon.dto;

import lombok.Data;

@Data
public class FilterWord {

    private int fno;
    private String word;

}
