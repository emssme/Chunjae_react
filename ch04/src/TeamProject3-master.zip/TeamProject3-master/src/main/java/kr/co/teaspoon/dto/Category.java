package kr.co.teaspoon.dto;

import lombok.Data;

@Data
public class Category {
    private String cate;
    private String cateName;
}
