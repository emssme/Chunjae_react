package kr.co.teaspoon.dto;

import lombok.Data;

@Data
public class Attendance {
    private int ano;
    private String id;
    private String attend;
}
