package kr.co.teaspoon.util;

public class AdminInterceptor {
}
