package kr.co.teaspoon.dto;

        import lombok.Data;

@Data
public class WinnerList {
    private int appno;
    private int eno;
    private String id;
    private String name;
    private String tel;
}